﻿namespace PhoneBookApp
{
    internal class Program
    {
        static void Main(string[] args)
        {


            PhoneBook book = new PhoneBook();

            //just made a  little  swtich display that we learn in the first stage of the course to make it look a little better
            bool running = true;
            while (running)
            {
                Console.WriteLine("\nPhone Book Application");
                Console.WriteLine("1. Display Unsorted List");
                Console.WriteLine("2. Display Sorted List");
                Console.WriteLine("3. Display Using 2D Array");
                Console.WriteLine("4. Exit");
                Console.Write("Enter your choice: ");

                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        book.DisplayOriginalList();
                        break;
                    case "2":
                        book.DisplaySortedList();
                        break;
                    case "3":
                        book.DisplayTable();
                        break;
                    case "4":
                        running = false;
                        break;
                    default:
                        Console.WriteLine("Invalid choice, please try again.");
                        break;
                }
            }
        }
    }
}