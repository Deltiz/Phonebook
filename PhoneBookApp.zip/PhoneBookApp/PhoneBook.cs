﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace PhoneBookApp
{
    //1. made a clsss to represent my phone book
    public class PhoneBook
    {
        private string[] names = { "Alexi", "Monsif", "David", "Hans" };
        private string[] numbers = { "123456789", "987654321", "123123123", "321321321" };
        private string[,] table;

        //constructor thata just called the instance and not the whole class 
        public PhoneBook()
        {
          
           InitializeTable();// teh 2d array to create the object not sure if this is right could maded a string array and called it table, and let a loop fill it up
           

        }
        //dispaly the original list
        public void DisplayOriginalList()
        {
            Console.WriteLine("Original List:");
            for (int i = 0; i < names.Length; i++)
            {
                Console.WriteLine("Name: " + names[i] + "\t Number: " + numbers[i]);
            }
        }

        //display the sorted list feel like i could have made a method that just sorted the list and then called it in the display method
        public void DisplaySortedList()
        {
            BubbleSort();
            Console.WriteLine("Sorted List:");
            for (int i = 0; i < names.Length; i++)
            {
                Console.WriteLine("Name: " + names[i] + "\t Number: " + numbers[i]);
            }
        }


        //here i am initializing the 2d array with naames and numbers
        public void InitializeTable()
        {//setting the size of the 3d array to the size of the 1d arrays
            table = new string[names.Length, 2]; 

            //lopping the 2d array made a Console.writeLine and printet it just to get it
            for (int i = 0; i < names.Length; i++)
            {
                table[i, 0] = names[i];
                table[i, 1] = numbers[i];
            }
        }

      // BUBBLEALGORITHM that sorts the names and numbers by comparing them and then swaping them if the first is bigger than the second saving the first in a
      // temp variable and then swaping them
        private void BubbleSort()
        {
            for (int i = 0; i < names.Length; i++)
            {
                for (int j = 0; j < names.Length - 1; j++)
                {
                    if (names[j].CompareTo(names[j + 1]) > 0)
                    {
                        string temp = names[j];
                        names[j] = names[j + 1];
                        names[j + 1] = temp;
                        //swopping the numbers aswell
                        string temp2 = numbers[j];
                        numbers[j] = numbers[j + 1];
                        numbers[j + 1] = temp2;
                    }
                }
            }

        }

        //display mytabke method that loops through the 2d array and prints it out
        public void MyTable()
        {
            table = new string[names.Length, 2];
            for (int i = 0; i < names.Length; i++)
            {
                table[i, 0] = names[i];
                table[i, 1] = numbers[i];
            }

        }
 //display table method that loops through the 2d array and prints it out
        public void DisplayTable()
        { Console.WriteLine("usng a 2d arry instad of two 1d arrays");
            for (int i = 0; i < table.GetLength(0); i++)
            {
                Console.WriteLine("Name: " + table[i, 0] + ", Number: " + table[i, 1]);
            }
        }
    }

}
    


    